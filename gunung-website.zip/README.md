# Eksplorasi Gunung Indonesia

Website sederhana bertema gunung-gunung di Indonesia.

## Fitur
- Halaman Home
- Daftar Gunung
- Desain sederhana HTML & CSS

## Cara Menjalankan
Buka file `index.html` di browser.
